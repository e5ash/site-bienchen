#!/usr/bin/env bash
rm -rf css js src
cp -r ../perfect-scrollbar/dist/css ./
cp -r ../perfect-scrollbar/dist/js ./
cp -r ../perfect-scrollbar/src ./
