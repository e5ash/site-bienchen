# Bower Package of perfect-scrollbar

This is the [Bower](https://bower.io/) package of perfect-scrollbar.

For details and usage please read more on [https://github.com/noraesae/perfect-scrollbar](https://github.com/noraesae/perfect-scrollbar).
